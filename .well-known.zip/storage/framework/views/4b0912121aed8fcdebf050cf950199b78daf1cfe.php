<?php $__env->startSection('title', 'من نحن |'); ?>
<?php $__env->startSection('content'); ?>
<!-- Start Breadcrumb
    ============================================= -->
<div class="breadcrumb-area gradient-bg text-light text-center">
    <!-- Fixed BG -->
    <div class="fixed-bg" style="background-image: url(<?php echo e(asset('frontend')); ?>/assets/img/shape/1.png);"></div>
    <!-- Fixed BG -->
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h1>تعرف علينا</h1>
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('home')); ?>"><i class="fas fa-home"></i> الرئيسية</a></li>
                    
                    <li class="active">تعرف علينا</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumb -->

<!-- Start Our About
    ============================================= -->
<div class="about-area bg-gray overflow-hidden rectangular-shape default-padding">
    <div class="container">
        <div class="about-items choseus-items right-thumb">
            <div class="row align-center">
                <div class="col-lg-6">
                    <div class="info wow fadeInLeft">
                        <small>من نحن</small>
                        <h2><?php echo e(aboutUs()->title_aboutus); ?></h2>
                        <p>
                            <?php echo e(aboutUs()->desc_aboutus); ?>

                        </p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="thumb wow fadeInUp" data-wow-delay="0.5s">
                        <img src="<?php echo e(asset('frontend')); ?>/assets/img/illustration/7.png" alt="Thumb">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Our About -->

<!-- Start Our About
    ============================================= -->
<div class="about-area bg-dark overflow-hidden rectangular-shape default-padding">
    <div class="container">
        <div class="about-items choseus-items left-thumb">
            <div class="row align-center">
                <div class="col-lg-6">
                    <div class="info wow fadeInRight">
                        <small class="text-warning">كلمة المدير</small>
                        <h2 class="text-white"><?php echo e(aboutUs()->title_admin_word); ?></h2>
                        <p class="text-muted">
                            <?php echo e(aboutUs()->desc_admin_word); ?>

                        </p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="thumb wow fadeInUp" data-wow-delay="0.5s">
                        <img src="<?php echo e(asset('frontend')); ?>/assets/img/illustration/4.png" alt="Thumb">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Our About -->

<!-- Start Our About
    ============================================= -->
<div class="about-area bg-white overflow-hidden default-padding">
    <div class="container">
        <div class="about-items choseus-items left-thumb">
            <div class="row align-center">
                <div class="col-lg-6">
                    <div class="thumb wow fadeInUp" data-wow-delay="0.5s">
                        <img src="<?php echo e(asset('frontend')); ?>/assets/img/illustration/1.png" alt="Thumb">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="info wow fadeInRight">
                        <small>مهمتنا</small>
                        <h2><?php echo e(aboutUs()->title_our_mission); ?></h2>
                        <p>
                            <?php echo e(aboutUs()->desc_our_mission); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Our About -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/medialab/yascenter.medialab.ae/resources/views/frontend/about-us.blade.php ENDPATH**/ ?>