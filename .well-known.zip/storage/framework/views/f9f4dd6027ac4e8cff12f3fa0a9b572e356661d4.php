    <!-- JAVASCRIPT -->
    <script src="<?php echo e(asset('backend/assets/libs/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/node-waves/waves.min.js')); ?>"></script>


    <!-- App js -->
    <script src="<?php echo e(asset('backend/assets/js/app.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH /home/yascenter/public_html/resources/views/dashboard/layouts/scripts.blade.php ENDPATH**/ ?>