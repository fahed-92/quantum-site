{{ csrf_field() }}

<div class="col-xl-12">
    <div class="mb-3">
        <h4 class="card-title bg-dark py-3 text-center text-white fs-14 shadow-sm">من نحن</h4>
    </div>
</div>

<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">العنوان</label>
        <input name="title_aboutus" class="form-control @error('title_aboutus') is-invalid  @enderror"
            value="{{ isset($row) ? $row->title_aboutus : old('title_aboutus') }}">
        @error('title_aboutus')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">الوصف</label>
        <textarea class="form-control @error('desc_aboutus') is-invalid  @enderror" name="desc_aboutus"
            rows="11">{{ isset($row) ? $row->desc_aboutus : old('desc_aboutus') }}</textarea>
        @error('desc_aboutus')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-12">
    <div class="mb-3 mt-3">
        <h4 class="card-title bg-dark py-3 text-center text-white fs-14 shadow-sm">مهمتنا</h4>
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">العنوان</label>
        <input name="title_our_mission" class="form-control @error('title_our_mission') is-invalid  @enderror"
            value="{{ isset($row) ? $row->title_our_mission : old('title_our_mission') }}">
        @error('title_our_mission')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">الوصف</label>
        <textarea class="form-control @error('desc_our_mission') is-invalid  @enderror" name="desc_our_mission"
            rows="11">{{ isset($row) ? $row->desc_our_mission : old('desc_our_mission') }}</textarea>
        @error('desc_our_mission')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-12">
    <div class="mb-3 mt-3">
        <h4 class="card-title bg-dark py-3 text-center text-white fs-14 shadow-sm">كلمة المدير</h4>
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">العنوان</label>
        <input name="title_admin_word" class="form-control @error('title_admin_word') is-invalid  @enderror"
            value="{{ isset($row) ? $row->title_admin_word : old('title_admin_word') }}">
        @error('title_admin_word')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">الوصف</label>
        <textarea class="form-control @error('desc_admin_word') is-invalid  @enderror" name="desc_admin_word"
            rows="11">{{ isset($row) ? $row->desc_admin_word : old('desc_admin_word') }}</textarea>
        @error('desc_admin_word')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

