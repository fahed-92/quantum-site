    <!-- Star Footer
    ============================================= -->
    <footer>
        <div class="container">
            <div class="f-items default-padding">
                <div class="row">
                    <div class="equal-height col-lg-6 col-md-6 item">
                        <div class="f-item about">
                            <img src="{{ asset('frontend') }}/assets/img/logo.svg" alt="Logo" width="100">
                            <p>{{ setting()->description ?? '' }}</p>
                        </div>
                    </div>

                    <!-- <div class="equal-height col-lg-2 col-md-6 item">
                        <div class="f-item link">
                            <h4 class="widget-title">روابط مفيدة</h4>
                            <ul>
                                <li>
                                    <a href="#">معلومات عنا</a>
                                </li>
                                <li>
                                    <a href="#">إتصل بنا</a>
                                </li>
                            </ul>
                        </div>
                    </div> -->

                    <div class="equal-height col-lg-2 col-md-6 item">
                        <div class="f-item link">
                            <h4 class="widget-title">خدمات</h4>
                            <ul>
                                @foreach (services_nav()->take(3) as $item)
                                    <li><a href="{{ route('service', [$item->id, $item->slug]) }}">{{ $item->title }}</a></li>
                                @endforeach
                                <li>
                                    <a href="{{ route('services') }}">جميع الخدمات</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="equal-height col-lg-4 col-md-6 item">
                        <div class="f-item contact">
                            <h4 class="widget-title">معلومات الاتصال</h4>
                            <p>
                                {{ setting()->title ?? '' }}
                            </p>
                            <div class="address">
                                <ul>
                                    <li>
                                        <strong>البريد الإلكتروني:</strong> {{ setting()->email_website ?? '' }}
                                    </li>
                                    <li>
                                        <strong>اتصل:</strong> {{ setting()->mobile_website ?? '' }}
                                    </li>
                                    <li>
                                        <strong>العنوان :</strong> {{ setting()->address_center ?? '' }}
                                    </li>
                                    <li>
                                        <strong>ساعات العمل :</strong> {{ setting()->time_work ?? '' }}
                                    </li>
                                </ul>
                            </div>
                            <ul class="social">
                                   <li class="instagram">
                                    <a href="{{ setting()->instagram_link ?? '#' }}"><i class="fa-brands fa-instagram"></i></a>
                                </li>
                                <li class="facebook">
                                    <a href="{{ setting()->facebook_link ?? '#' }}"><i class="fa-brands fa-facebook"></i></a>
                                </li>
                                <li class="twitter">
                                    <a href="{{ setting()->twitter_link ?? '#' }}"><i class="fa-brands fa-twitter"></i></a>
                                </li>
                                <li class="youtube">
                                    <a href="{{ setting()->youtube_link ?? '#' }}"><i class="fa-brands fa-youtube"></i></a>
                                </li>
                                    <li class="snapchat">
                                    <a href="{{ setting()->snapchat_link ?? '#' }}"><i class="fa-brands fa-snapchat"></i></a>
                                </li>
                                     <li class="tiktok">
                                    <a href="{{ setting()->tiktok_link ?? '#' }}"><i class="fa-brands fa-tiktok"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="row">
                    <div class="col-lg-6">
                        <p>&copy; حقوق الطبع والنشر 2022. جميع الحقوق محفوظة <a href="{{ route('home') }}">مركز ياس</a></p>
                    </div>
                    <div class="col-lg-6 text-right link">
                        <ul>
                            <li>
                                <a href="#">شروط</a>
                            </li>
                            <li>
                                <a href="#">خصوصية</a>
                            </li>
                            <li>
                                <a href="#">الدعم</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Shape -->
        <div class="footer-shape" style="background-image: url({{ asset('frontend') }}/assets/img/shape/1.svg);"></div>
        <!-- End Shape -->
    </footer>
    <!-- End Footer-->

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="{{ asset('frontend') }}/assets/js/jquery-1.12.4.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/popper.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/bootstrap.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/equal-height.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/jquery.appear.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/jquery.easing.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/jquery.magnific-popup.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/modernizr.custom.13711.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/owl.carousel.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/wow.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/progress-bar.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/isotope.pkgd.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/count-to.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/YTPlayer.min.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/circle-progress.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/bootsnav.js"></script>
    <script src="{{ asset('frontend') }}/assets/js/main.js"></script>
    @stack('scripts')
