        <!-- Start Navigation -->
        <nav class="navbar navbar-default inc-top-bar attr-border navbar-fixed {{ Request::is('/') || Request::is('home') ? 'dark' : 'white' }} no-background bootsnav">
            {{-- <!-- Start Top Search -->
            <div class="container">
                <div class="row">
                    <div class="top-search">
                        <div class="input-group">
                            <form action="#">
                                <input type="text" name="text" class="form-control" placeholder="Search">
                                <button type="submit">
                                    <i class="ti-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Top Search --> --}}

            <div class="container">

                {{-- <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <li class="search"><a href="#"><i class="ti-search"></i></a></li>
                    </ul>
                </div>
                <!-- End Atribute Navigation --> --}}

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="{{ route('home') }}">
                        @if(Request::is('/') || Request::is('home'))
                        <img src="{{ asset('frontend') }}/assets/img/logo.svg" class="logo" alt="Logo" width="100">
                        @else
                        <img src="{{ asset('frontend') }}/assets/img/logo-white.svg" class="logo" alt="Logo" width="100">
                        @endif
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
                        <li>
                            <a href="{{ route('home') }}" class="active">الصفحة الرئيسية</a>
                        </li>
                        <li><a href="{{ route('about-us') }}">تعرف علينا</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">خدمات المركز</a>
                            <ul class="dropdown-menu">
                                @foreach (services_nav()->take(4) as $item)
                                    <li><a href="{{ route('service', [$item->id, $item->slug]) }}">{{ $item->title }}</a></li>
                                @endforeach
                                <li><a href="{{ route('services') }}">جميع الخدمات</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="{{ route('contact-us') }}">إتصل بنا</a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->
