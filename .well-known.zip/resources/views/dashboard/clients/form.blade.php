{{ csrf_field() }}

<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">الأسم</label>
        <input name="title" class="form-control @error('title') is-invalid  @enderror"
            value="{{ isset($row) ? $row->title : old('title') }}">
        @error('title')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>
<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">اختار صورة</label>
        <div class="input-group">
            <span class="input-group-btn">
                <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                    <i class="fa fa-picture-o"></i> اختار صورة
                </a>
            </span>
            <input id="thumbnail" class="form-control @error('image') is-invalid  @enderror" type="text" name="image"
                value="{{ isset($row) ? $row->image : old('image') }}">
        </div>
        @error('image')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">عرض الصورة</label>
        <div id="holder" style="max-height:70px; overflow: hidden; object-fit: contain;">
            @if(isset($row))
            <img src="{{ $row->image }}" class="img-thumbnail img-fluid" width="70" alt="">
            @endif
        </div>
    </div>
</div>


@push('scripts')
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
    $('#lfm').filemanager('image');
</script>
@endpush
