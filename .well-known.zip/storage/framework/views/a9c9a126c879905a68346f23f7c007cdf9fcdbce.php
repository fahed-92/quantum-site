<?php echo e(csrf_field()); ?>


<div class="col-xl-12">
    <div class="mb-3">
        <h4 class="card-title bg-dark py-3 text-center text-white fs-14 shadow-sm">من نحن</h4>
    </div>
</div>

<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">العنوان</label>
        <input name="title_aboutus" class="form-control <?php $__errorArgs = ['title_aboutus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(isset($row) ? $row->title_aboutus : old('title_aboutus')); ?>">
        <?php $__errorArgs = ['title_aboutus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class=" text text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">الوصف</label>
        <textarea class="form-control <?php $__errorArgs = ['desc_aboutus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="desc_aboutus"
            rows="11"><?php echo e(isset($row) ? $row->desc_aboutus : old('desc_aboutus')); ?></textarea>
        <?php $__errorArgs = ['desc_aboutus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class=" text text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="col-xl-12">
    <div class="mb-3 mt-3">
        <h4 class="card-title bg-dark py-3 text-center text-white fs-14 shadow-sm">مهمتنا</h4>
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">العنوان</label>
        <input name="title_our_mission" class="form-control <?php $__errorArgs = ['title_our_mission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(isset($row) ? $row->title_our_mission : old('title_our_mission')); ?>">
        <?php $__errorArgs = ['title_our_mission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class=" text text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">الوصف</label>
        <textarea class="form-control <?php $__errorArgs = ['desc_our_mission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="desc_our_mission"
            rows="11"><?php echo e(isset($row) ? $row->desc_our_mission : old('desc_our_mission')); ?></textarea>
        <?php $__errorArgs = ['desc_our_mission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class=" text text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="col-xl-12">
    <div class="mb-3 mt-3">
        <h4 class="card-title bg-dark py-3 text-center text-white fs-14 shadow-sm">كلمة المدير</h4>
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">العنوان</label>
        <input name="title_admin_word" class="form-control <?php $__errorArgs = ['title_admin_word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(isset($row) ? $row->title_admin_word : old('title_admin_word')); ?>">
        <?php $__errorArgs = ['title_admin_word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class=" text text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">الوصف</label>
        <textarea class="form-control <?php $__errorArgs = ['desc_admin_word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="desc_admin_word"
            rows="11"><?php echo e(isset($row) ? $row->desc_admin_word : old('desc_admin_word')); ?></textarea>
        <?php $__errorArgs = ['desc_admin_word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class=" text text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<?php /**PATH /home/yascenter/public_html/resources/views/dashboard/aboutuses/form.blade.php ENDPATH**/ ?>