<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->
    <?php echo $__env->make('frontend.layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Start Header Top
    ============================================= -->
    <div class="top-bar-area inline inc-border">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-9 col-md-12 address-info text-left">
                    <div class="info box">
                        <ul>
                            <li>
                                <i class="fas fa-map-marker-alt"></i>
                                <p>
                                    <?php echo e(setting()->address_center ?? ''); ?>

                                </p>
                            </li>
                            <li>
                                <i class="fas fa-envelope-open"></i>
                                <p>
                                    <?php echo e(setting()->email_website ?? ''); ?>

                                </p>
                            </li>
                            <li>
                                <i class="fas fa-phone"></i>
                                <p>
                                    <?php echo e(setting()->mobile_website ?? ''); ?>

                                </p>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12 info-right">
                    <div class="item-flex border-less">
                        <div class="social">
                            <ul>
                                <li class="facebook">
                                    <a href="<?php echo e(setting()->facebook_link ?? '#'); ?>"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li class="twitter">
                                    <a href="<?php echo e(setting()->twitter_link ?? '#'); ?>"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li class="pinterest">
                                    <a href="<?php echo e(setting()->youtube_link ?? '#'); ?>"><i class="fab fa-youtube"></i></a>
                                </li>
                                <li class="linkedin">
                                    <a href="<?php echo e(setting()->instagram_link ?? '#'); ?>"><i class="fab fa-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Top -->

    <!-- Header
    ============================================= -->
    <header id="home">

        <?php echo $__env->make('frontend.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </header>
    <!-- End Header -->

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH /home/medialab/yascenter.medialab.ae/resources/views/frontend/layouts/master.blade.php ENDPATH**/ ?>