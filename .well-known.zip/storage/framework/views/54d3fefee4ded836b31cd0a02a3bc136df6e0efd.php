<head>

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('dashboard.layouts.metatags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('backend/assets/css/bootstrap-rtl.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('backend/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('backend/assets/css/app-rtl.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('backend/assets/css/main-custom.css')); ?>" rel="stylesheet" type="text/css" />
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<?php /**PATH /home/vtmdev/yascenter.vtmdev.com/resources/views/dashboard/layouts/head.blade.php ENDPATH**/ ?>