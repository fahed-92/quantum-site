<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\aboutUs;
use Illuminate\Http\Request;

class AboutUsController extends BackEndController
{
    public function __construct(aboutUs $model)
    {
        parent::__construct($model);
    }


    public function update(Request $request, $id)
    {
        $aboutus = $this->model->findOrFail($id);
        if ($aboutus) {
            $this->validate($request, [
                'title_aboutus'=> 'required',
                'title_our_mission'=> 'required',
                'title_admin_word'=> 'required',
                'desc_aboutus'=> 'required',
                'desc_our_mission'=> 'required',
                'desc_admin_word'=> 'required',
            ]);
            $data = $request->except('id');
            $aboutus->fill($data)->save();
            return back()->with('success', 'تم تحديث البيانات بنجاح');
        }
    }
}
