<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.7/dist/sweetalert2.all.min.js"></script>
<script>
const Toast = Swal.mixin({
  toast: true,
  position: 'top-start',
  iconColor: 'white',
  customClass: {
    popup: 'colored-toast'
  },
  showConfirmButton: false,
  timer: 4000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }

});
</script>
<?php $__env->stopPush(); ?>
<?php if(session('success')): ?>
<?php $__env->startPush('scripts'); ?>
<script>
    Toast.fire({
    icon: 'success',
    title: '<?php echo e(session('success')); ?>'
    });
</script>
<?php $__env->stopPush(); ?>

<?php elseif(session('error')): ?>

<?php $__env->startPush('scripts'); ?>
<script>
    Toast.fire({
    icon: 'error',
    title: '<?php echo e(session('error')); ?>'
    });
</script>
<?php $__env->stopPush(); ?>

<?php endif; ?>
<?php /**PATH /home/vtmdev/yascenter.vtmdev.com/resources/views/dashboard/layouts/alerts.blade.php ENDPATH**/ ?>