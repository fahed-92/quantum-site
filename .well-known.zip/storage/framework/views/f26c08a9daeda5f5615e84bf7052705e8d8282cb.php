    <!-- Star Footer
    ============================================= -->
    <footer>
        <div class="container">
            <div class="f-items default-padding">
                <div class="row">
                    <div class="equal-height col-lg-6 col-md-6 item">
                        <div class="f-item about">
                            <img src="<?php echo e(asset('frontend')); ?>/assets/img/logo.svg" alt="Logo" width="100">
                            <p><?php echo e(setting()->description ?? ''); ?></p>
                        </div>
                    </div>

                    <!-- <div class="equal-height col-lg-2 col-md-6 item">
                        <div class="f-item link">
                            <h4 class="widget-title">روابط مفيدة</h4>
                            <ul>
                                <li>
                                    <a href="#">معلومات عنا</a>
                                </li>
                                <li>
                                    <a href="#">إتصل بنا</a>
                                </li>
                            </ul>
                        </div>
                    </div> -->

                    <div class="equal-height col-lg-2 col-md-6 item">
                        <div class="f-item link">
                            <h4 class="widget-title">خدمات</h4>
                            <ul>
                                <?php $__currentLoopData = services_nav()->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('service', [$item->id, $item->slug])); ?>"><?php echo e($item->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('services')); ?>">جميع الخدمات</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="equal-height col-lg-4 col-md-6 item">
                        <div class="f-item contact">
                            <h4 class="widget-title">معلومات الاتصال</h4>
                            <p>
                                <?php echo e(setting()->title ?? ''); ?>

                            </p>
                            <div class="address">
                                <ul>
                                    <li>
                                        <strong>البريد الإلكتروني:</strong> <?php echo e(setting()->email_website ?? ''); ?>

                                    </li>
                                    <li>
                                        <strong>اتصل:</strong> <?php echo e(setting()->mobile_website ?? ''); ?>

                                    </li>
                                    <li>
                                        <strong>العنوان :</strong> <?php echo e(setting()->address_center ?? ''); ?>

                                    </li>
                                    <li>
                                        <strong>ساعات العمل :</strong> <?php echo e(setting()->time_work ?? ''); ?>

                                    </li>
                                </ul>
                            </div>
                            <ul class="social">
                                <li class="facebook">
                                    <a href="<?php echo e(setting()->facebook_link ?? '#'); ?>"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li class="twitter">
                                    <a href="<?php echo e(setting()->twitter_link ?? '#'); ?>"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li class="youtube">
                                    <a href="<?php echo e(setting()->youtube_link ?? '#'); ?>"><i class="fab fa-youtube"></i></a>
                                </li>
                                <li class="instagram">
                                    <a href="<?php echo e(setting()->instagram_link ?? '#'); ?>"><i class="fab fa-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="row">
                    <div class="col-lg-6">
                        <p>&copy; حقوق الطبع والنشر 2022. جميع الحقوق محفوظة <a href="<?php echo e(route('home')); ?>">مركز ياس</a></p>
                    </div>
                    <div class="col-lg-6 text-right link">
                        <ul>
                            <li>
                                <a href="#">شروط</a>
                            </li>
                            <li>
                                <a href="#">خصوصية</a>
                            </li>
                            <li>
                                <a href="#">الدعم</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Shape -->
        <div class="footer-shape" style="background-image: url(<?php echo e(asset('frontend')); ?>/assets/img/shape/1.svg);"></div>
        <!-- End Shape -->
    </footer>
    <!-- End Footer-->

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/jquery-1.12.4.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/popper.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/equal-height.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/jquery.appear.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/jquery.easing.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/modernizr.custom.13711.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/wow.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/progress-bar.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/isotope.pkgd.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/count-to.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/YTPlayer.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/circle-progress.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/bootsnav.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/main.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH /home/vtmdev/yascenter.vtmdev.com/resources/views/frontend/layouts/footer.blade.php ENDPATH**/ ?>