<?php

namespace App\Http\Controllers\FrontEnd;
use App\Http\Controllers\Controller;
use App\Mail\NotifyMail;
use App\Models\RequestService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class RequestController extends Controller
{
    public function send(Request $request)
    {
        $this->validate($request, [
            'full_name', 'required',
            'email', 'email|required',
            'phone', 'required',
            'address', 'required',
            'message', 'required'
        ]);
        $data = $request->except('_token');
        $emails = [ $data['email'], setting()->email_website ];
        RequestService::create($data);
        Mail::to($emails)->send(new NotifyMail($data));
        return redirect()->route('home')->with('success', 'تم إرسال الطلب بنجاح سنتواصل معك عبر البريد الإلكتروني');
    }
}
