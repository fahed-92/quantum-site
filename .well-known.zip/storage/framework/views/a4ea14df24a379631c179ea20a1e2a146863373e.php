        <!-- Start Navigation -->
        <nav class="navbar navbar-default inc-top-bar attr-border navbar-fixed <?php echo e(Request::is('/') || Request::is('home') ? 'dark' : 'white'); ?> no-background bootsnav">
            

            <div class="container">

                

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                        <?php if(Request::is('/') || Request::is('home')): ?>
                        <img src="<?php echo e(asset('frontend')); ?>/assets/img/logo.svg" class="logo" alt="Logo" width="100">
                        <?php else: ?>
                        <img src="<?php echo e(asset('frontend')); ?>/assets/img/logo-white.svg" class="logo" alt="Logo" width="100">
                        <?php endif; ?>
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
                        <li>
                            <a href="<?php echo e(route('home')); ?>" class="active">الصفحة الرئيسية</a>
                        </li>
                        <li><a href="<?php echo e(route('about-us')); ?>">تعرف علينا</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">خدمات المركز</a>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = services_nav()->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('service', [$item->id, $item->slug])); ?>"><?php echo e($item->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('services')); ?>">جميع الخدمات</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="<?php echo e(route('contact-us')); ?>">إتصل بنا</a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->
<?php /**PATH /home/yascenter/public_html/resources/views/frontend/layouts/navbar.blade.php ENDPATH**/ ?>