<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Faq;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ClientsController extends BackEndController
{

    public function __construct(Client $model)
    {
        parent::__construct($model);

    }

    public function store(Request $request) {
        $module_name_plural = $this->getClassNameFromModel();
        $this->validate($request, [
            'title'=> 'required',
            'image'=> 'required',
        ]);

        $data = $request->all();
        $status = $this->model->create($data);
        if($status){
            return redirect()->route('dashboard.' . $module_name_plural . '.index')->with('success', 'تم إضافة العنصر بنجاح');
        }
    }

    public function update(Request $request, $id)
    {
        $service = $this->model->findOrFail($id);
        if ($service) {
            $this->validate($request, [
                'title'=> 'required',
                'image'=> 'required',
            ]);
            $data = $request->except('id');
            $service->fill($data)->save();
            return back()->with('success', 'تم تحديث البيانات بنجاح');
        }
    }

}
