<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.7/dist/sweetalert2.all.min.js"></script>
<script>
    const Toast = Swal.mixin({
  toast: true,
  position: 'top-start',
  iconColor: 'white',
  customClass: {
    popup: 'colored-toast'
  },
  showConfirmButton: false,
  timer: 6000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }

});
</script>
<?php $__env->stopPush(); ?>
<?php if(session('success')): ?>
<?php $__env->startPush('scripts'); ?>
<script>

Swal.fire({
  title: 'عملية ناجحة',
  text: '<?php echo e(session('success')); ?>',
  icon: 'success',
  confirmButtonText: 'Thanks'
});

    // Swal.fire(
    //     'عملية ناجحه',
    //     '<?php echo e(session('success')); ?>',
    //     'success'
    // )
</script>
<?php $__env->stopPush(); ?>

<?php elseif(session('error')): ?>

<?php $__env->startPush('scripts'); ?>
<script>
    Swal.fire(
        'لم يتم إكمال العملية',
        '<?php echo e(session('error')); ?>',
        'error'
    )
</script>
<?php $__env->stopPush(); ?>

<?php endif; ?>
<?php /**PATH /home/vtmdev/yascenter.vtmdev.com/resources/views/frontend/layouts/alerts.blade.php ENDPATH**/ ?>