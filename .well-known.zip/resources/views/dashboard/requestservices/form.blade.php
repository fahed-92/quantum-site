<div class="col-xl-4">
    <div class="mb-3">
        <label class="form-label">الأسم كامل</label>
        <input name="full_name" class="form-control" value="{{ $row->full_name }}" disabled>
    </div>
</div>
<div class="col-xl-4">
    <div class="mb-3">
        <label class="form-label">البريد الإلكتروني</label>
        <input name="email" class="form-control" value="{{ $row->email }}" disabled>
    </div>
</div>

<div class="col-xl-4">
    <div class="mb-3">
        <label class="form-label">الهاتف</label>
        <input name="phone" class="form-control" value="{{ $row->phone }}" disabled>
    </div>
</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">العنوان</label>
        <input name="address" class="form-control" value="{{ $row->address }}" disabled>
    </div>
</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">اسم الخدمة</label>
        <input name="address" class="form-control" value="{{ $service->title }}" disabled>
    </div>
</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">الرسالة</label>
        <textarea rows="8" class="form-control" disabled>{{ $row->message }}</textarea>
    </div>
</div>



<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">تفاصيل الخدمة</label>
        <textarea rows="8" class="form-control editor" disabled>{{ $service->description }}</textarea>
    </div>
</div>

@push('scripts')
<script src="{{ asset('backend/assets/build/ckeditor.js') }}"></script>
<script>ClassicEditor
        .create( document.querySelector( '.editor' ), {
            licenseKey: '',
        } )
        .then( editor => {
            window.editor = editor;
        } )
        .catch( error => {
            console.error( 'Oops, something went wrong!' );
            console.error( error );
        } );
</script>
@endpush
