<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="Medianature Dashboard" name="description" />
<meta content="Medianature" name="author" />
<!-- App favicon -->
<link rel="shortcut icon" href="{{ asset('backend') }}/assets/images/favicon.ico">
