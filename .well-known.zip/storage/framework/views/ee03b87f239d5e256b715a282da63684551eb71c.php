<?php $__env->startSection('title', $row->title.' |'); ?>
<?php $__env->startSection('content'); ?>
<!-- Start Breadcrumb
    ============================================= -->
<div class="breadcrumb-area gradient-bg text-light text-center">
    <!-- Fixed BG -->
    <div class="fixed-bg" style="background-image: url(<?php echo e(asset('frontend')); ?>/assets/img/shape/1.png);"></div>
    <!-- Fixed BG -->
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h1><?php echo e($row->title); ?></h1>
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('home')); ?>"><i class="fas fa-home"></i> الرئيسية</a></li>
                    <li><a href="<?php echo e(route('services')); ?>">خدمات المركز</a></li>
                    <li class="active"><?php echo e($row->title); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumb -->
<!-- Start Our About ============================================= -->
<div class="about-area bg-gray overflow-hidden default-padding">
    <div class="container">
        <div class="about-items choseus-items left-thumb">
            <div class="row align-center">
                <div class="col-lg-6">
                    <div class="thumb wow fadeInUp" data-wow-delay="0.5s">
                        
                        <img src="<?php echo e($row->image); ?>" class="img-fluid" alt="<?php echo e($row->title); ?>">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="info wow fadeInRight">
                        <small>خدمات المركز</small>
                        <h2><?php echo e($row->title); ?></h2>
                        <div><?php echo $row->description; ?></div>
                        <button type="button" class="btn btn-primary mt-3" data-toggle="modal" data-target="#request<?php echo e($row->id); ?>">
                            تقديم طلب
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Our About -->

<?php echo $__env->make('frontend.layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtmdev/yascenter.vtmdev.com/resources/views/frontend/services/single_service.blade.php ENDPATH**/ ?>