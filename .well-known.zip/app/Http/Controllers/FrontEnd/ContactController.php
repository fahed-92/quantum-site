<?php

namespace App\Http\Controllers\FrontEnd;

use App\Http\Controllers\Controller;
use App\Mail\ContactUsMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function index()
    {
        return view('frontend.contact-us');
    }

    public function send(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'phone' => 'required',
            'email' => 'required|email',
            'messages' => 'required'
        ]);
        $data = $request->all();
        Mail::to(setting()->email_website)->send(new ContactUsMail($data));
        return back()->with('success', 'تم إرسال الرسالة بنجاح');
    }

}
