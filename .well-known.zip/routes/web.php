<?php

use App\Http\Controllers\Dashboard\AboutUsController;
use App\Http\Controllers\Dashboard\ClientsController;
use App\Http\Controllers\Dashboard\ContactUsController;
use App\Http\Controllers\Dashboard\DashboardController;
use App\Http\Controllers\Dashboard\FaqController;
use App\Http\Controllers\Dashboard\RequestServiceController;
use App\Http\Controllers\Dashboard\ServicesController;
use App\Http\Controllers\Dashboard\SettingsController;
use App\Http\Controllers\FrontEnd\AboutUsController as FrontEndAboutUsController;
use App\Http\Controllers\FrontEnd\ClientsController as FrontEndClientsController;
use App\Http\Controllers\FrontEnd\ContactController;
use App\Http\Controllers\FrontEnd\HomeController;
use App\Http\Controllers\FrontEnd\RequestController;
use App\Http\Controllers\FrontEnd\ServicesController as FrontEndServicesController;
use App\Models\aboutUs;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// FrontEnd
Route::get('/', [HomeController::class, 'index']);
Route::get('/home', [HomeController::class, 'index'])->name('home');
###########################################[ AboutUs ]########################################
Route::get('about-us', [FrontEndAboutUsController::class, 'index'])->name('about-us');
###########################################[ Services ]########################################
Route::get('services', [FrontEndServicesController::class, 'index'])->name('services');
Route::get('service/{id}/{slug}', [FrontEndServicesController::class, 'single_service'])->name('service');
Route::post('request/send', [RequestController::class, 'send'])->name('request.send');
###########################################[ clients ]########################################
Route::get('clients', [FrontEndClientsController::class, 'index'])->name('clients');
###########################################[ Contact Us ]########################################
Route::get('contact-us', [ContactController::class, 'index'])->name('contact-us');
Route::post('contact-us/send', [ContactController::class, 'send'])->name('contact-us.send');




// Dashboard
Route::prefix('dashboard')->name('dashboard.')->group(function () {
    // Authenticate
    Auth::routes();
    // Dashboard
    Route::middleware(['auth'])->group(function () {
        Route::get('/', [DashboardController::class, 'index'])->name('index');
        Route::get('/home', [DashboardController::class, 'index'])->name('index');

        ###########################################[ Settings ]########################################
        Route::resource('settings', SettingsController::class);
        ###########################################[ AboutUs ]########################################
        Route::resource('aboutus', AboutUsController::class);
        ###########################################[ Services ]########################################
        Route::resource('services', ServicesController::class);
        ###########################################[ Faqs ]########################################
        Route::resource('faqs', FaqController::class);
        ###########################################[ Clients ]########################################
        Route::resource('clients', ClientsController::class);
        ###########################################[ Requests ]########################################
        Route::resource('requests', RequestServiceController::class);
        ###########################################[ Contact Ys ]########################################
        // Route::get('contactus', [ContactUsController::class, 'index'])->name('contact.index');
        // Route::get('contactus/show', [ContactUsController::class, 'show'])->name('contact.show');
    });

});
