<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ServicesController extends BackEndController
{



    public function __construct(Service $model)
    {
        parent::__construct($model);

    }

    public function store(Request $request) {
        $module_name_plural = $this->getClassNameFromModel();
        $this->validate($request, [
            'title'=> 'required',
            'description'=> 'required',
            'image'=> 'required',
        ]);

        $data = $request->all();
        $slug = my_slug($request->input('title'));
        $slug_count = Service::where('slug', $slug)->count();
        if($slug_count>0){
            $slug .= time(). '-' . $slug;
        }
        $data['slug'] = $slug;
        $status = $this->model->create($data);
        if($status){
            return redirect()->route('dashboard.' . $module_name_plural . '.index')->with('success', 'تم إضافة الخدمة بنجاح');
        }
    }

    public function update(Request $request, $id)
    {
        $service = $this->model->findOrFail($id);
        if ($service) {
            $this->validate($request, [
                'title'=> 'required',
                'description'=> 'required',
                'image'=> 'required',
            ]);
            $data = $request->except('id');
            $service->fill($data)->save();
            return back()->with('success', 'تم تحديث البيانات بنجاح');
        }
    }

}
