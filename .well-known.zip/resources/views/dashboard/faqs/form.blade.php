{{ csrf_field() }}

<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">السؤال</label>
        <input name="title" class="form-control @error('title') is-invalid  @enderror"
            value="{{ isset($row) ? $row->title : old('title') }}">
        @error('title')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>
<div class="col-xl-12">
    <div class="mb-3">
        <label class="form-label">الإجابة</label>
        <textarea class="form-control @error('description') is-invalid  @enderror" name="description"
            rows="11">{{ isset($row) ? $row->description : old('description') }}</textarea>
        @error('description')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>
