<!DOCTYPE html>
<html lang="ar">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ========== Page Title ========== -->
    <title><?php echo $__env->yieldContent('title'); ?> <?php echo e(setting()->title ?? ''); ?></title>
    <meta name="title" content="<?php echo $__env->yieldContent('title'); ?> <?php echo e(setting()->title ?? ''); ?>">
    <meta name="description" content="<?php echo e(setting()->description ?? ''); ?>">
    <meta name="keywords" content="<?php echo e(setting()->keywords ?? ''); ?>">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="language" content="Arabic">
    <meta name="revisit-after" content="10 days">
    <meta name="author" content="MediaNature">

    <!-- Facebook Meta Tags -->
    <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?> <?php echo e(setting()->title ?? ''); ?>">
    <meta property="og:description" content="<?php echo e(setting()->description ?? ''); ?>">
    <meta property="og:image" content="<?php echo e(asset('frontend/assets/img/og.png')); ?>">

    <!-- Twitter Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta property="twitter:domain" content="yascenter.vtmdev.com">
    <meta property="twitter:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('title'); ?> <?php echo e(setting()->title ?? ''); ?>">
    <meta name="twitter:description" content="<?php echo e(setting()->description ?? ''); ?>">
    <meta name="twitter:image" content="<?php echo e(asset('frontend/assets/img/og.png')); ?>">

    <!-- ========== Favicon Icon ========== -->
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('frontend/assets/img/favicon.svg')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('frontend/assets/img/favicon.png')); ?>">

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/themify-icons.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/flaticon-set.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/magnific-popup.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/owl.carousel.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/owl.theme.default.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/animate.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/bootsnav.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/style.css" rel="stylesheet">
    <link href="<?php echo e(asset('frontend')); ?>/assets/css/responsive.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="<?php echo e(asset('frontend')); ?>/assets/js/html5/html5shiv.min.js"></script>
      <script src="<?php echo e(asset('frontend')); ?>/assets/js/html5/respond.min.js"></script>
    <![endif]-->

    <!-- ========== Google Fonts ========== -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('backend/assets/css/main-custom.css')); ?>" rel="stylesheet" type="text/css" />
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<?php /**PATH /home/medialab/yascenter.medialab.ae/resources/views/frontend/layouts/header.blade.php ENDPATH**/ ?>