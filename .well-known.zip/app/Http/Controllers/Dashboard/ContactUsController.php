<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ContactUsController extends BackEndController
{
    public function show($id)
    {
        return view('dashboard.contactus.show');
    }
}
