        <!-- ========== Right Sidebar Start ========== -->
        <div class="vertical-menu">

            <div data-simplebar class="h-100">

                <!--- Sidemenu -->
                <div id="sidebar-menu">
                    <!-- Right Menu Start -->
                    <ul class="metismenu list-unstyled" id="side-menu">
                        <li>
                            <a href="<?php echo e(route('dashboard.index')); ?>" class="waves-effect">
                                <i class="bx bx-home-circle"></i>
                                <span key="t-dashboards">لوحة التحكم</span>
                            </a>
                        </li>

                        <li>
                            <a href="javascript: void(0);" class="has-arrow waves-effect">
                                <i class="bx bx-globe"></i>
                                <span key="t-sites">الموقع</span>
                            </a>
                            <ul class="sub-menu" aria-expanded="false">
                                <li><a href="<?php echo e(route('dashboard.settings.edit', 1)); ?>" key="t-home">اعدادات الموقع</a></li>
                                <li><a href="<?php echo e(route('dashboard.aboutus.edit', 1)); ?>" key="t-about">من نحن</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="javascript: void(0);" class="has-arrow waves-effect">
                                <i class="bx bx-layout"></i>
                                <span key="t-categories">الخدمات</span>
                            </a>
                            <ul class="sub-menu" aria-expanded="false">
                                <li><a href="<?php echo e(route('dashboard.services.create')); ?>" key="t-add-cat">إضافة خدمة</a></li>
                                <li><a href="<?php echo e(route('dashboard.services.index')); ?>" key="t-view-cats">كل الخدمات</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="javascript: void(0);" class="has-arrow waves-effect">
                                <i class="bx bx-group"></i>
                                <span key="t-clients">العملاء والشركاء</span>
                            </a>
                            <ul class="sub-menu" aria-expanded="false">
                                <li><a href="<?php echo e(route('dashboard.clients.create')); ?>" key="t-add-client">إضافة</a></li>
                                <li><a href="<?php echo e(route('dashboard.clients.index')); ?>" key="t-view-client">عرض الكل</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="javascript: void(0);" class="has-arrow waves-effect">
                                <i class="bx bx-question-mark"></i>
                                <span key="t-question">الأسئلة الشائعة</span>
                            </a>
                            <ul class="sub-menu" aria-expanded="false">
                                <li><a href="<?php echo e(route('dashboard.faqs.create')); ?>" key="t-add-question">إضافة</a></li>
                                <li><a href="<?php echo e(route('dashboard.faqs.index')); ?>" key="t-view-question">عرض الكل</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="<?php echo e(route('dashboard.requests.index')); ?>" class="waves-effect">
                                <i class="bx bx-male-sign"></i>
                                <span key="t-request">طلبات التقديم</span>
                            </a>
                        </li>

                    </ul>
                </div>
                <!-- Sidebar -->
            </div>
        </div>
        <!-- Right Sidebar End -->
<?php /**PATH /home/vtmdev/yascenter.vtmdev.com/resources/views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>