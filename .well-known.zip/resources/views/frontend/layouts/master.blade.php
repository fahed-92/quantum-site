@include('frontend.layouts.header')

<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->
    @include('frontend.layouts.alerts')
    <!-- Start Header Top
    ============================================= -->
    <div class="top-bar-area inline inc-border">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-9 col-md-12 address-info text-left">
                    <div class="info box">
                        <ul>
                            <li>
                                <i class="fas fa-map-marker-alt"></i>
                                <p>
                                    {{ setting()->address_center ?? '' }}
                                </p>
                            </li>
                            <li>
                                <i class="fas fa-envelope-open"></i>
                                <p>
                                    {{ setting()->email_website ?? '' }}
                                </p>
                            </li>
                            <li>
                                <i class="fas fa-phone"></i>
                                <p>
                                    {{ setting()->mobile_website ?? '' }}
                                </p>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12 info-right">
                    <div class="item-flex border-less">
                        <div class="social">
                            <ul>
                                 <li class="instagram">
                                    <a href="{{ setting()->instagram_link ?? '#' }}"><i class="fa-brands fa-instagram"></i></a>
                                </li>
                                <li class="facebook">
                                    <a href="{{ setting()->facebook_link ?? '#' }}"><i class="fa-brands fa-facebook"></i></a>
                                </li>
                                <li class="twitter">
                                    <a href="{{ setting()->twitter_link ?? '#' }}"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li class="youtube">
                                    <a href="{{ setting()->youtube_link ?? '#' }}"><i class="fa-brands fa-youtube"></a>
                                </li>
                                  <li class="snapchat">
                                    <a href="{{ setting()->snapchat_link ?? '#' }}"><i class="fab fa-snapchat"></i></a>
                                </li>
                                  <li class="tiktok">
                                    <a href="{{ setting()->tiktok_link ?? '#' }}"><i class="fab fa-tiktok"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Top -->

    <!-- Header
    ============================================= -->
    <header id="home">

        @include('frontend.layouts.navbar')

    </header>
    <!-- End Header -->

    @yield('content')

    @include('frontend.layouts.footer')

</body>

</html>
