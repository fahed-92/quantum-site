<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\RequestService;
use App\Models\Service;
use App\Models\UserActivity;
use App\Notifications\ReporterNotifications;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {

        $todatRequest = RequestService::whereDate('created_at', Carbon::today())->count();
        $lastMonthRequest = RequestService::whereDate('created_at', Carbon::today()->subDay(30))->count();
        $newRequests = RequestService::take(5)->get();
        $services = Service::count();

        $statistics = RequestService::where('created_at', '>', DB::raw('DATE_ADD(CURDATE(), INTERVAL -1 DAY)'))
        ->select([DB::raw('"طلبات اليوم" as date'), DB::raw('count(id) as total')])
        ->union(
            RequestService::where('created_at', '>', DB::raw('DATE_ADD(CURDATE(), INTERVAL -7 DAY)'))
                ->select([DB::raw('"طلبات أخر 7 ايام"'), DB::raw('count(id) as total')])
        )
        ->union(
            RequestService::where('created_at', '>', DB::raw('DATE_ADD(CURDATE(), INTERVAL -30 DAY)'))
                ->select([DB::raw('"طلبات الشهر"'), DB::raw('count(id) as total')])
        )
        ->union(
            RequestService::select([DB::raw('"عدد الطلبات"'), DB::raw('count(id) as total')])
        )
        ->get();
        return view('dashboard.home', compact('todatRequest', 'lastMonthRequest', 'newRequests', 'services', 'statistics'));
    }
}
