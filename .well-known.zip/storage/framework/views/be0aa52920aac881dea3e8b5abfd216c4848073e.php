<?php $__env->startSection('title'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Banner
    ============================================= -->
    <div class="banner-area thumb-pos pad-responsive text-combo shape-top">
        <div class="item">
            <div class="box-table">
                <div class="box-cell">
                    <div class="container">
                        <div class="row">
                            <div class="double-items">
                                <div class="col-lg-6 info">
                                    <h2 class="wow fadeInDown" data-wow-duration="1s"><span><?php echo e(setting()->sub_title); ?></span> <?php echo e(setting()->title_header); ?></h2>
                                    <a class="btn circle btn-md btn-gradient wow fadeInUp" data-wow-duration="1.8s" href="<?php echo e(route('about-us')); ?>">تعرف علينا أكثر <i class="fas fa-plus"></i></a>
                                </div>
                                <div class="col-lg-6 thumb">
                                    <img class="wow fadeInRight img-fluid" src="https://lh3.googleusercontent.com/p/AF1QipNRxZ_G1VSbi8IDkLcCJJnXy4tntVShQHErcmO9=s1280-p-no-v1" alt="Thumb">
                                    <!-- <img class="absolute wow fadeInUp" data-wow-duration="2.5s" src="assets/img/illustration/17.png" alt="Thumb"> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Banner -->

    <!-- Star About Area
    ============================================= -->
    <div class="about-area shape-left relative">
        <div class="container">
            <div class="items-box">
                <div class="row">
                    <div class="col-lg-6 thumb wow fadeInDown">
                        <img src="<?php echo e(asset('frontend')); ?>/assets/img/illustration/9.png" alt="Thumb">
                    </div>
                    <div class="col-lg-6 info wow fadeInRight" data-wow-duration="1.3s">
                        <div class="about-tabs">
                            <ul id="tabs" class="nav nav-tabs">
                                <li class="nav-item">
                                    <a href="" data-target="#tab1" data-toggle="tab" class="active nav-link">من نحن</a>
                                </li>
                                <li class="nav-item">
                                    <a href="" data-target="#tab2" data-toggle="tab" class="nav-link">مهمتنا</a>
                                </li>
                                <li class="nav-item">
                                    <a href="" data-target="#tab3" data-toggle="tab" class="nav-link">رؤيتنا</a>
                                </li>
                            </ul>
                            <div id="tabsContent" class="tab-content wow fadeInUp" data-wow-delay="0.5s">
                                <div id="tab1" class="tab-pane fade active show">
                                    <h2><?php echo e(aboutUs()->title_aboutus); ?></h2>
                                    <p><?php echo e(aboutUs()->desc_aboutus); ?></p>
                                    <a class="btn circle btn-md btn-gradient icon-left" href="<?php echo e(route('about-us')); ?>">المزيد من المعلومات</a>
                                </div>
                                <div id="tab2" class="tab-pane fade">
                                    <h2><?php echo e(aboutUs()->title_our_mission); ?></h2>
                                    <p><?php echo e(aboutUs()->desc_our_mission); ?></p>
                                    <a class="btn circle btn-md btn-gradient icon-left" href="<?php echo e(route('about-us')); ?>">المزيد من المعلومات</a>
                                </div>
                                <div id="tab3" class="tab-pane fade">
                                    <h2><?php echo e(aboutUs()->title_admin_word); ?></h2>
                                    <p><?php echo e(aboutUs()->desc_admin_word); ?></p>
                                    <a class="btn circle btn-md btn-gradient icon-left" href="<?php echo e(route('about-us')); ?>">المزيد من المعلومات</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About Area -->

    <!-- Start Services
    ============================================= -->
    <div class="services-area text-center carousel-shadow wavesshape-bottom default-padding-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4>خدماتنا</h4>
                        <h2>
                            الذي نفعله
                        </h2>
                    </div>
                </div>
            </div>
            <div class="service-items">
                <div class="row">
                    <div class="feature-box text-left col-lg-12">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="feature-2-col-carousel owl-carousel owl-theme">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Single Item -->
                                    <div class="item">
                                        <div class="image-service mb-3" style="width: 100%; height: 200px;">
                                            <img src="<?php echo e($row->image); ?>" class="img-fluid" style="object-fit: cover; height: 100%;" alt="<?php echo e($row->title); ?>">
                                        </div>
                                        <div class="info">
                                            <h4><?php echo e($row->title); ?></h4>
                                            <p><?php echo Str::limit(strip_tags($row->description), 155, '...'); ?></p>
                                        </div>
                                        <div class="bottom">
                                            <a class="btn circle btn-sm btn-gradient" href="<?php echo e(route('service', [$row->id, $row->slug])); ?>">إقرأ المزيد <i class="fas fa-plus"></i></a>
                                        </div>
                                    </div>
                                    <!-- End Single Item -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="waveshape">
            <img src="<?php echo e(asset('frontend')); ?>/assets/img/shape/2.svg" alt="Shape">
        </div>
    </div>
    <!-- End Services -->

    <!-- Star Clients Area
    ============================================= -->
    <div class="clients-area overflow-hidden default-padding bg-gradient text-light">
        <div class="container">
            <div class="client-items">
                <div class="row align-center">
                    <div class="col-lg-5 info">
                        <h5>العملاء والشركاء</h5>
                        <h2>اكتشف قصص العملاء الناجحة</h2>
                        <p>
                            تكيفت مع ابتسامة الإناث يا رحلة بي انكشف القلق. التقى يأتي إضافة الهدوء البارد ما ميل ما. بلاط مانور في مبنى تم بناؤه بواسطة مكان فاني. التقدير في أن يكون حاسما جدا.
                        </p>
                    </div>
                    <div class="col-lg-6 offset-lg-1">
                        <div class="clients-carousel owl-carousel owl-theme">
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <img src="<?php echo e($row->image); ?>" alt="<?php echo e($row->title); ?>">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Clients Area -->

    <?php if($faq->count() > 0): ?>
    <!-- Star Faq
    ============================================= -->
    <div class="faq-area default-padding bg-gray">
        <div class="container">
            <div class="faq-items">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="faq-content">
                            <h2>الأسئلة الشائعة</h2>
                            <div class="accordion" id="accordionExample">
                                <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card">
                                    <div class="card-header" id="headingOne<?php echo e($row->id); ?>">
                                        <h4 class="mb-0" data-toggle="collapse" data-target="#collapseOne<?php echo e($row->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                                            <?php echo e($row->title); ?>

                                        </h4>
                                    </div>

                                    <div id="collapseOne<?php echo e($row->id); ?>" class="collapse <?php if($loop->first): ?> show <?php endif; ?>" aria-labelledby="headingOne<?php echo e($row->id); ?>" data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p><?php echo e($row->description); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="thumb wow fadeInLeft" data-wow-delay="0.5s">
                            <img src="<?php echo e(asset('frontend')); ?>/assets/img/illustration/9.png" alt="Thumb">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Faq -->
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yascenter/public_html/resources/views/frontend/home.blade.php ENDPATH**/ ?>