<?php

namespace App\Http\Controllers\FrontEnd;

use App\Http\Controllers\Controller;
use App\Models\Service;
use Illuminate\Http\Request;

class ServicesController extends Controller
{
    public function index()
    {
        $rows = Service::get();
        return view('frontend.services.services', compact('rows'));
    }

    public function single_service($id, $slug){
        $row = Service::where(['id'=>$id, 'slug'=>$slug])->first();
        if(!$row){
            return abort('404');
        }
        return view('frontend.services.single_service', compact('row'));
    }



}
