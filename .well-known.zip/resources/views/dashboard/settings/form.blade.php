{{ csrf_field() }}


<div class="col-xl-4">
    <div class="mb-3">
        <label class="form-label">اسم الموقع</label>
        <input name="title" class="form-control @error('title') is-invalid  @enderror"
            value="{{ isset($row) ? $row->title : old('title') }}">
        @error('title')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-4">
    <div class="mb-3">
        <label class="form-label">البريد الإلكتروني</label>
        <input name="email_website" class="form-control @error('email_website') is-invalid  @enderror"
            value="{{ isset($row) ? $row->email_website : old('	email_website') }}">
        @error('email_website')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>


<div class="col-xl-4">
    <div class="mb-3">
        <label class="form-label">رقم الهاتف</label>
        <input name="mobile_website" class="form-control @error('mobile_website') is-invalid  @enderror"
            value="{{ isset($row) ? $row->mobile_website : old('mobile_website') }}">
        @error('mobile_website')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>


<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">الكلمات الدلالية</label>
        <textarea class="form-control @error('keywords') is-invalid  @enderror" name="keywords"
            rows="11">{{ isset($row) ? $row->keywords : old('keywords') }}</textarea>
        @error('keywords')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">الوصف</label>
        <textarea class="form-control @error('description') is-invalid  @enderror" name="description"
            rows="11">{{ isset($row) ? $row->description : old('description') }}</textarea>
        @error('description')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>



{{-- Social Media --}}

<div class="col-xl-3">
    <div class="mb-3">
        <label class="form-label">انستجرام</label>
        <input type="text" name="instagram_link" class="form-control @error('instagram_link') is-invalid  @enderror"
            value="{{ isset($row) ? $row->instagram_link : old('instagram_link') }}">
        @error('instagram_link')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>

<div class="col-xl-3">
    <div class="mb-3">
        <label class="form-label">الفيس بوك</label>
        <input type="text" name="facebook_link" class="form-control @error('facebook_link') is-invalid  @enderror"
            value="{{ isset($row) ? $row->facebook_link : old('facebook_link') }}">
        @error('facebook_link')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-3">
    <div class="mb-3">
        <label class="form-label">تويتر</label>
        <input type="text" name="twitter_link" class="form-control @error('twitter_link') is-invalid  @enderror"
            value="{{ isset($row) ? $row->twitter_link : old('twitter_link') }}">
        @error('twitter_link')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-3">
    <div class="mb-3">
        <label class="form-label">يوتيوب</label>
        <input type="text" name="youtube_link" class="form-control @error('youtube_link') is-invalid  @enderror"
            value="{{ isset($row) ? $row->youtube_link : old('youtube_link') }}">
        @error('youtube_link')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
    <div class="col-xl-3">
    <div class="mb-3">
        <label class="form-label">سناب شات</label>
        <input type="text" name="snapchat_link" class="form-control @error('snapchat') is-invalid  @enderror"
            value="{{ isset($row) ? $row->snapchat_link : old('snapchat_link') }}">
        @error('snapchat_link')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>


</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">عنوان المركز</label>
        <input name="address_center" class="form-control @error('address_center') is-invalid  @enderror"
            value="{{ isset($row) ? $row->address_center : old('address_center') }}">
        @error('address_center')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">مواعيد العمل</label>
        <input name="time_work" class="form-control @error('time_work') is-invalid  @enderror"
            value="{{ isset($row) ? $row->time_work : old('time_work') }}">
        @error('time_work')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-12">
    <div class="mb-3">
        <h4 class="card-title bg-dark py-3 text-center text-white fs-14 shadow-sm">رأس الصفحة</h4>
    </div>
</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">مركز ياس</label>
        <input name="sub_title" class="form-control @error('sub_title') is-invalid  @enderror"
            value="{{ isset($row) ? $row->sub_title : old('sub_title') }}">
        @error('sub_title')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>

<div class="col-xl-6">
    <div class="mb-3">
        <label class="form-label">أكبر مركز في الدولة على مساحة 1600 متر.</label>
        <input name="title_header" class="form-control @error('title_header') is-invalid  @enderror"
            value="{{ isset($row) ? $row->title_header : old('title_header') }}">
        @error('title_header')
        <small class=" text text-danger" role="alert">
            <strong>{{ $message }}</strong>
        </small>
        @enderror
    </div>
</div>
