<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Settings;
use App\Models\UserActivity;
use Illuminate\Http\Request;

class SettingsController extends BackEndController
{
    public function __construct(Settings $model)
    {
        parent::__construct($model);
    }


    public function update(Request $request, $id)
    {
        $setting = $this->model->findOrFail($id);
        if ($setting) {
            $this->validate($request, [
                'title'=> 'required',
                'keywords'=> 'required',
                'description'=> 'required',
                'email_website'=> 'nullable',
                'mobile_website'=> 'required',
                'sub_title'=> 'required',
                'title_header'=> 'required',
                'address_center'=> 'required',
                'time_work'=> 'required',
                'facebook_link'=> 'required|url',
                'twitter_link'=> 'required|url',
                'youtube_link'=> 'required|url',
                'instagram_link'=> 'required|url',
            ]);
            $data = $request->except('id');
            $setting->fill($data)->save();
            return back()->with('success', 'تم تحديث البيانات بنجاح');
        }
    }

}
