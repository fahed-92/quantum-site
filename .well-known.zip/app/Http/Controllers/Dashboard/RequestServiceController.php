<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\RequestService;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class RequestServiceController extends BackEndController
{



    public function __construct(RequestService $model)
    {
        parent::__construct($model);

    }


    public function show($id)
    {
        $row = $this->model->findOrFail($id)->first();
        $service = Service::where('id', $row->service_id)->first();
        return view('dashboard.requestservices.show', compact('row', 'service'));
    }


}
